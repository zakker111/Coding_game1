import React from 'react'
import { Link } from 'react-router-dom'

import type { KnownReplayEvent, Loadout, ModuleId, Replay, ReplayEvent, SlotId } from '@coding-game/replay'

import { EXAMPLE_BOTS, EXAMPLE_OPPONENT_IDS } from '../exampleBots'
import {
  createNewLocalBotId,
  createDefaultLocalBotLibrary,
  loadLocalBotLibrary,
  saveLocalBotLibrary,
  type LocalBotLibraryV2,
} from '../localBots'
import { selectDistinctFromPool } from '../opponents'
import { applyLoadoutHeaderDirectives, DEFAULT_WORKSHOP_LOADOUT, parseLoadoutHeaderDirectives } from '../loadout'
import { fnv1a32 } from '../worker/seed'

import { initialPlaybackState, playbackReducer } from '../replay/playbackReducer'
import { getAppearanceColorMap, getBotsForPlayback, SLOT_IDS } from '../replay/interpolate'
import { ArenaCanvas, type ArenaRenderState } from '../ui/arena'
import { runLocalInWorker } from '../worker/runLocalInWorker'

const LOADOUT_OPTION_VALUES = ['EMPTY', 'BULLET', 'SAW', 'SHIELD', 'ARMOR'] as const
type LoadoutOptionValue = (typeof LOADOUT_OPTION_VALUES)[number]

function parseLoadoutOptionValue(v: string): ModuleId | null {
  const upper = String(v ?? '').toUpperCase()
  if (upper === 'EMPTY') return null
  if (upper === 'BULLET' || upper === 'SAW' || upper === 'SHIELD' || upper === 'ARMOR') return upper
  return null
}

function formatLoadoutOptionValue(mod: ModuleId | null): LoadoutOptionValue {
  if (mod === 'BULLET' || mod === 'SAW' || mod === 'SHIELD' || mod === 'ARMOR') return mod
  return 'EMPTY'
}

const OPPONENT_NONCE_KEY = 'nowt:workshop:opponentNonce:v1'
const OPPONENT_ASSIGNMENTS_KEY = 'nowt:workshop:opponents:v1'

type OpponentAssignments = {
  BOT2: string
  BOT3: string
  BOT4: string
}

type StoredOpponentAssignmentsV1 = {
  version: 1
} & OpponentAssignments

const DEFAULT_OPPONENT_ASSIGNMENTS: StoredOpponentAssignmentsV1 = {
  version: 1,
  BOT2: 'bot2',
  BOT3: 'bot3',
  BOT4: 'bot4',
}

const OPPONENT_SLOTS = ['BOT2', 'BOT3', 'BOT4'] as const

function readOpponentNonce(): number {
  try {
    const raw = localStorage.getItem(OPPONENT_NONCE_KEY)
    const n = raw == null ? 0 : Number(raw)
    return Number.isFinite(n) ? (n >>> 0) : 0
  } catch {
    return 0
  }
}

function writeOpponentNonce(n: number) {
  try {
    localStorage.setItem(OPPONENT_NONCE_KEY, String(n >>> 0))
  } catch {
    // ignore
  }
}

function readOpponentAssignments(): OpponentAssignments {
  try {
    const raw = localStorage.getItem(OPPONENT_ASSIGNMENTS_KEY)
    if (!raw) {
      return {
        BOT2: DEFAULT_OPPONENT_ASSIGNMENTS.BOT2,
        BOT3: DEFAULT_OPPONENT_ASSIGNMENTS.BOT3,
        BOT4: DEFAULT_OPPONENT_ASSIGNMENTS.BOT4,
      }
    }

    const parsed = JSON.parse(raw) as Partial<StoredOpponentAssignmentsV1>
    if (parsed.version !== 1) {
      return {
        BOT2: DEFAULT_OPPONENT_ASSIGNMENTS.BOT2,
        BOT3: DEFAULT_OPPONENT_ASSIGNMENTS.BOT3,
        BOT4: DEFAULT_OPPONENT_ASSIGNMENTS.BOT4,
      }
    }

    return {
      BOT2: typeof parsed.BOT2 === 'string' ? parsed.BOT2 : DEFAULT_OPPONENT_ASSIGNMENTS.BOT2,
      BOT3: typeof parsed.BOT3 === 'string' ? parsed.BOT3 : DEFAULT_OPPONENT_ASSIGNMENTS.BOT3,
      BOT4: typeof parsed.BOT4 === 'string' ? parsed.BOT4 : DEFAULT_OPPONENT_ASSIGNMENTS.BOT4,
    }
  } catch {
    return {
      BOT2: DEFAULT_OPPONENT_ASSIGNMENTS.BOT2,
      BOT3: DEFAULT_OPPONENT_ASSIGNMENTS.BOT3,
      BOT4: DEFAULT_OPPONENT_ASSIGNMENTS.BOT4,
    }
  }
}

function normalizeOpponentAssignments(prev: OpponentAssignments, poolIds: string[]): OpponentAssignments {
  if (poolIds.length < 3) {
    throw new Error(`Not enough opponent choices (${poolIds.length})`)
  }

  const used = new Set<string>()
  const next: OpponentAssignments = { ...prev }

  for (const slot of OPPONENT_SLOTS) {
    const current = prev[slot]

    if (poolIds.includes(current) && !used.has(current)) {
      next[slot] = current
      used.add(current)
      continue
    }

    const replacement = poolIds.find((id) => !used.has(id))
    if (!replacement) break

    next[slot] = replacement
    used.add(replacement)
  }

  if (next.BOT2 === prev.BOT2 && next.BOT3 === prev.BOT3 && next.BOT4 === prev.BOT4) return prev
  return next
}

function isRelevantEvent(e: ReplayEvent, botId: SlotId): boolean {
  switch (e.type) {
    case 'BOT_EXEC':
    case 'BOT_MOVED':
    case 'RESOURCE_DELTA':
    case 'BUMP_WALL':
      return e.botId === botId
    case 'BUMP_BOT':
      return e.botId === botId || e.otherBotId === botId
    case 'BULLET_SPAWN':
      return e.ownerBotId === botId || e.targetBotId === botId
    case 'BULLET_HIT':
      return e.victimBotId === botId
    case 'DAMAGE':
      return e.victimBotId === botId || e.sourceBotId === botId
    case 'BOT_DIED':
      return e.victimBotId === botId || e.creditedBotId === botId
    case 'POWERUP_PICKUP':
      return e.botId === botId
    case 'POWERUP_SPAWN':
    case 'POWERUP_DESPAWN':
      return true
    default:
      return false
  }
}

function isKnownReplayEventType<TType extends KnownReplayEvent['type']>(
  e: ReplayEvent,
  type: TType,
): e is Extract<KnownReplayEvent, { type: TType }> {
  return e.type === type
}

function deriveLoadoutFromScriptOrDefault(sourceText: string): Loadout {
  const parsed = parseLoadoutHeaderDirectives(sourceText)
  return parsed.hasDirectives ? parsed.loadout : DEFAULT_WORKSHOP_LOADOUT
}

type OpponentOption = {
  id: string
  displayName: string
  sourceText: string
  loadout: Loadout
}

type AppliedRunInfo = {
  seed: number
  tickCap: number
  bot1Id: string
  bot1Name: string
  botSpecHashBySlot: Record<SlotId, number>
}

export function WorkshopPage() {
  const [seed, setSeed] = React.useState<number>(12345)
  const [tickCap, setTickCap] = React.useState<number>(200)

  const starterSourceText = EXAMPLE_BOTS.bot0.sourceText

  const [myBots, setMyBots] = React.useState<LocalBotLibraryV2>(() =>
    createDefaultLocalBotLibrary(starterSourceText),
  )
  const [opponents, setOpponents] = React.useState<OpponentAssignments>({
    BOT2: DEFAULT_OPPONENT_ASSIGNMENTS.BOT2,
    BOT3: DEFAULT_OPPONENT_ASSIGNMENTS.BOT3,
    BOT4: DEFAULT_OPPONENT_ASSIGNMENTS.BOT4,
  })
  const [loaded, setLoaded] = React.useState(false)

  const [editingBotId, setEditingBotId] = React.useState<SlotId>('BOT1')
  const [selectedBotId, setSelectedBotId] = React.useState<SlotId>('BOT1')

  const [running, setRunning] = React.useState(false)
  const [runError, setRunError] = React.useState<string | null>(null)
  const [appliedRun, setAppliedRun] = React.useState<AppliedRunInfo | null>(null)

  const [showRawTickEvents, setShowRawTickEvents] = React.useState(false)

  const [playback, dispatch] = React.useReducer(playbackReducer, initialPlaybackState)
  const [alpha, setAlpha] = React.useState(1)

  React.useEffect(() => {
    setMyBots(loadLocalBotLibrary(starterSourceText))
    setOpponents(readOpponentAssignments())
    setLoaded(true)
  }, [starterSourceText])

  React.useEffect(() => {
    if (!loaded) return
    saveLocalBotLibrary(myBots)
  }, [loaded, myBots])

  React.useEffect(() => {
    if (!loaded) return

    try {
      const stored: StoredOpponentAssignmentsV1 = { version: 1, ...opponents }
      localStorage.setItem(OPPONENT_ASSIGNMENTS_KEY, JSON.stringify(stored))
    } catch {
      // ignore quota/unavailable
    }
  }, [loaded, opponents])

  const selectedMyBot = React.useMemo(() => {
    return myBots.bots.find((b) => b.id === myBots.selectedBotId) ?? myBots.bots[0]
  }, [myBots])

  const opponentPool: OpponentOption[] = React.useMemo(() => {
    const exampleOpponents: OpponentOption[] = EXAMPLE_OPPONENT_IDS.map((id) => ({
      id,
      displayName: EXAMPLE_BOTS[id].displayName,
      sourceText: EXAMPLE_BOTS[id].sourceText,
      loadout: deriveLoadoutFromScriptOrDefault(EXAMPLE_BOTS[id].sourceText),
    }))

    const localOpponents: OpponentOption[] = myBots.bots
      .filter((b) => b.id !== selectedMyBot.id)
      .slice()
      .sort((a, b) => a.id.localeCompare(b.id))
      .map((b) => ({
        id: b.id,
        displayName: `${b.name} (my bot)`,
        sourceText: b.sourceText,
        loadout: b.loadout,
      }))

    return [...exampleOpponents, ...localOpponents]
  }, [myBots.bots, selectedMyBot.id])

  const opponentPoolById = React.useMemo(() => {
    return new Map(opponentPool.map((o) => [o.id, o]))
  }, [opponentPool])

  const opponentPoolIds = React.useMemo(() => opponentPool.map((o) => o.id), [opponentPool])

  React.useEffect(() => {
    setOpponents((prev) => normalizeOpponentAssignments(prev, opponentPoolIds))
  }, [opponentPoolIds])

  const sourcesBySlot: Record<SlotId, string> = React.useMemo(() => {
    return {
      BOT1: selectedMyBot.sourceText,
      BOT2: opponentPoolById.get(opponents.BOT2)?.sourceText ?? '',
      BOT3: opponentPoolById.get(opponents.BOT3)?.sourceText ?? '',
      BOT4: opponentPoolById.get(opponents.BOT4)?.sourceText ?? '',
    }
  }, [opponents.BOT2, opponents.BOT3, opponents.BOT4, opponentPoolById, selectedMyBot.sourceText])

  const loadoutBySlot: Record<SlotId, Loadout> = React.useMemo(() => {
    return {
      BOT1: selectedMyBot.loadout ?? DEFAULT_WORKSHOP_LOADOUT,
      BOT2: opponentPoolById.get(opponents.BOT2)?.loadout ?? DEFAULT_WORKSHOP_LOADOUT,
      BOT3: opponentPoolById.get(opponents.BOT3)?.loadout ?? DEFAULT_WORKSHOP_LOADOUT,
      BOT4: opponentPoolById.get(opponents.BOT4)?.loadout ?? DEFAULT_WORKSHOP_LOADOUT,
    }
  }, [opponents.BOT2, opponents.BOT3, opponents.BOT4, opponentPoolById, selectedMyBot.loadout])

  const displayNameBySlot: Record<SlotId, string> = React.useMemo(() => {
    const normalizeOpponentLabel = (name: string) => name.replace(/\s+\(my bot\)$/, '')

    return {
      BOT1: selectedMyBot.name,
      BOT2: normalizeOpponentLabel(opponentPoolById.get(opponents.BOT2)?.displayName ?? 'BOT2'),
      BOT3: normalizeOpponentLabel(opponentPoolById.get(opponents.BOT3)?.displayName ?? 'BOT3'),
      BOT4: normalizeOpponentLabel(opponentPoolById.get(opponents.BOT4)?.displayName ?? 'BOT4'),
    }
  }, [opponents.BOT2, opponents.BOT3, opponents.BOT4, opponentPoolById, selectedMyBot.name])

  const currentBotSpecHashBySlot: Record<SlotId, number> = React.useMemo(() => {
    const sig = (loadout: Loadout) => loadout.map((s) => (s == null ? 'EMPTY' : s)).join(',')

    return {
      BOT1: fnv1a32(`${sourcesBySlot.BOT1}\n${sig(loadoutBySlot.BOT1)}\n`),
      BOT2: fnv1a32(`${sourcesBySlot.BOT2}\n${sig(loadoutBySlot.BOT2)}\n`),
      BOT3: fnv1a32(`${sourcesBySlot.BOT3}\n${sig(loadoutBySlot.BOT3)}\n`),
      BOT4: fnv1a32(`${sourcesBySlot.BOT4}\n${sig(loadoutBySlot.BOT4)}\n`),
    }
  }, [loadoutBySlot, sourcesBySlot])

  const previewUpToDate = React.useMemo(() => {
    if (!playback.replay || !appliedRun) return false
    if (appliedRun.seed !== seed) return false
    if (appliedRun.tickCap !== tickCap) return false
    if (appliedRun.bot1Id !== selectedMyBot.id) return false

    return SLOT_IDS.every((slotId) => appliedRun.botSpecHashBySlot[slotId] === currentBotSpecHashBySlot[slotId])
  }, [appliedRun, currentBotSpecHashBySlot, playback.replay, seed, selectedMyBot.id, tickCap])

  const previewStatusText = !playback.replay ? 'Not run yet' : previewUpToDate ? 'Applied' : 'Out of date'

  React.useEffect(() => {
    const replay = playback.replay
    if (!replay) return

    if (!playback.playing) {
      setAlpha(1)
      return
    }

    let rafId = 0
    let lastNow = performance.now()
    let accMs = 0

    const tickMs = 1000 / replay.ticksPerSecond

    const frame = (now: number) => {
      const dt = now - lastNow
      lastNow = now

      accMs += dt * playback.speed

      const steps = Math.floor(accMs / tickMs)
      if (steps > 0) {
        accMs -= steps * tickMs
        dispatch({ type: 'STEP', delta: steps })
      }

      setAlpha(accMs / tickMs)
      rafId = window.requestAnimationFrame(frame)
    }

    rafId = window.requestAnimationFrame(frame)
    return () => window.cancelAnimationFrame(rafId)
  }, [playback.playing, playback.speed, playback.replay])

  const replay = playback.replay

  const appearanceMap = React.useMemo(() => {
    return replay ? getAppearanceColorMap(replay) : ({} as Record<SlotId, string>)
  }, [replay])

  const botsForRender = React.useMemo(() => {
    if (!replay) return []
    return getBotsForPlayback(replay, playback.tick, playback.playing ? alpha : 1)
  }, [alpha, playback.playing, playback.tick, replay])

  const bulletsForRender = React.useMemo(() => {
    if (!replay) return []

    const t = clamp(playback.tick, 0, replay.tickCap)
    const a = playback.playing ? alpha : 1

    const next = replay.state[t]
    const prev = t > 0 ? replay.state[t - 1] : next

    if (!next || !prev) return []

    const prevById = new Map(prev.bullets.map((b) => [b.bulletId, b]))
    const nextById = new Map(next.bullets.map((b) => [b.bulletId, b]))

    const bulletIds = new Set<string>()
    for (const b of prev.bullets) bulletIds.add(b.bulletId)
    for (const b of next.bullets) bulletIds.add(b.bulletId)

    const spawnsByBulletId = new Map(
      (replay.events[t] ?? [])
        .filter((e): e is Extract<KnownReplayEvent, { type: 'BULLET_SPAWN' }> => isKnownReplayEventType(e, 'BULLET_SPAWN'))
        .map((e) => [e.bulletId, e]),
    )

    const despawnsByBulletId = new Map(
      (replay.events[t] ?? [])
        .filter((e): e is Extract<KnownReplayEvent, { type: 'BULLET_DESPAWN' }> => isKnownReplayEventType(e, 'BULLET_DESPAWN'))
        .map((e) => [e.bulletId, e]),
    )

    const out = [] as Array<{
      bulletId: string
      ownerBotId: SlotId
      pos: { x: number; y: number }
      vel: { x: number; y: number }
      alpha?: number
    }>

    for (const bulletId of bulletIds) {
      const b0 = prevById.get(bulletId)
      const b1 = nextById.get(bulletId)
      if (!b0 && !b1) continue

      // Despawn: bullet present in prev, missing in next.
      if (b0 && !b1) {
        if (a >= 1) continue

        const despawn = despawnsByBulletId.get(bulletId)
        const to = despawn?.pos ?? b0.pos

        out.push({
          bulletId,
          ownerBotId: b0.ownerBotId,
          vel: b0.vel,
          pos: {
            x: b0.pos.x + (to.x - b0.pos.x) * a,
            y: b0.pos.y + (to.y - b0.pos.y) * a,
          },
          alpha: 1 - a,
        })
        continue
      }

      // Spawn: bullet missing in prev, present in next.
      if (!b0 && b1) {
        const spawn = spawnsByBulletId.get(bulletId)
        const from = spawn?.pos ?? { x: b1.pos.x - b1.vel.x, y: b1.pos.y - b1.vel.y }

        out.push({
          bulletId,
          ownerBotId: b1.ownerBotId,
          vel: b1.vel,
          pos: {
            x: from.x + (b1.pos.x - from.x) * a,
            y: from.y + (b1.pos.y - from.y) * a,
          },
        })
        continue
      }

      // Normal movement.
      const from = b0?.pos ?? b1!.pos
      const to = b1?.pos ?? b0!.pos
      const vel = b1?.vel ?? b0!.vel
      const ownerBotId = b1?.ownerBotId ?? b0!.ownerBotId

      out.push({
        bulletId,
        ownerBotId,
        vel,
        pos: {
          x: from.x + (to.x - from.x) * a,
          y: from.y + (to.y - from.y) * a,
        },
      })
    }

    return out
  }, [alpha, playback.playing, playback.tick, replay])

  const powerupsForRender = React.useMemo(() => {
    if (!replay) return []
    const t = clamp(playback.tick, 0, replay.tickCap)
    const snap = replay.state[t]
    const powerups = snap?.powerups ?? []

    return powerups.map((p) => ({
      powerupId: p.powerupId,
      kind: p.type,
      pos: powerupLocToWorld(p.loc),
    }))
  }, [playback.tick, replay])

  const renderState: ArenaRenderState = React.useMemo(() => {
    return {
      bots: botsForRender.map((b) => ({
        slotId: b.botId,
        pos: b.pos,
        hp: b.hp,
        ammo: b.ammo,
        energy: b.energy,
        alive: b.alive,
        appearanceColor: appearanceMap[b.botId],
        displayName: displayNameBySlot[b.botId],
      })),
      bullets: bulletsForRender,
      powerups: powerupsForRender,
    }
  }, [appearanceMap, botsForRender, bulletsForRender, displayNameBySlot, powerupsForRender])

  const selectedBotSnapshot = botsForRender.find((b) => b.botId === selectedBotId)

  const selectedTickEvents = React.useMemo(() => {
    if (!replay) return []
    const t = clamp(playback.tick, 0, replay.tickCap)
    return (replay.events[t] ?? []).filter((e): e is KnownReplayEvent => isRelevantEvent(e, selectedBotId))
  }, [playback.tick, replay, selectedBotId])

  const selectedTickEventLines = React.useMemo(() => {
    if (!selectedTickEvents.length) return []

    const lines: Array<{ key: string; label: string; detail?: string; tone?: 'muted' | 'bad' | 'good' }> = []

    for (let i = 0; i < selectedTickEvents.length; i++) {
      const e = selectedTickEvents[i]
      switch (e.type) {
        case 'BOT_EXEC': {
          const tone = e.result === 'EXECUTED' ? 'good' : e.reason ? 'bad' : 'muted'
          lines.push({
            key: `BOT_EXEC:${e.botId}:${e.pcBefore}:${e.pcAfter}`,
            label: `${e.botId} BOT_EXEC`,
            detail: `${e.instrText}  (pc ${e.pcBefore}→${e.pcAfter}, ${e.result}${e.reason ? `, ${e.reason}` : ''})`,
            tone,
          })
          break
        }
        case 'BOT_MOVED':
          lines.push({
            key: `BOT_MOVED:${e.botId}:${e.fromPos.x},${e.fromPos.y}->${e.toPos.x},${e.toPos.y}`,
            label: `${e.botId} moved`,
            detail: `${e.fromPos.x},${e.fromPos.y} → ${e.toPos.x},${e.toPos.y}${e.dir ? ` (${e.dir})` : ''}`,
          })
          break
        case 'BUMP_WALL':
          lines.push({
            key: `BUMP_WALL:${e.botId}:${e.dir}`,
            label: `${e.botId} bumped wall`,
            detail: `${e.dir} (damage ${e.damage})`,
            tone: e.damage > 0 ? 'bad' : 'muted',
          })
          break
        case 'BUMP_BOT':
          lines.push({
            key: `BUMP_BOT:${e.botId}:${e.otherBotId}:${e.dir}`,
            label: `bump`,
            detail: `${e.botId} ↔ ${e.otherBotId} (${e.dir})`,
          })
          break
        case 'RESOURCE_DELTA': {
          const parts = []
          if (e.healthDelta) parts.push(`HP ${e.healthDelta > 0 ? '+' : ''}${e.healthDelta}`)
          if (e.ammoDelta) parts.push(`AMMO ${e.ammoDelta > 0 ? '+' : ''}${e.ammoDelta}`)
          if (e.energyDelta) parts.push(`ENERGY ${e.energyDelta > 0 ? '+' : ''}${e.energyDelta}`)
          lines.push({
            key: `RESOURCE_DELTA:${e.botId}:${e.cause}:${parts.join(',')}`,
            label: `${e.botId} resources`,
            detail: `${parts.join(', ') || '(no delta)'} (${e.cause})`,
            tone: e.healthDelta < 0 ? 'bad' : e.healthDelta > 0 ? 'good' : 'muted',
          })
          break
        }
        case 'DAMAGE':
          lines.push({
            key: `DAMAGE:${e.victimBotId}:${e.amount}:${e.source}:${e.sourceBotId ?? ''}`,
            label: `damage`,
            detail: `${e.victimBotId} -${e.amount} (${e.source}${e.sourceBotId ? ` by ${e.sourceBotId}` : ''}, ${e.kind})`,
            tone: 'bad',
          })
          break
        case 'BOT_DIED':
          lines.push({
            key: `BOT_DIED:${e.victimBotId}:${e.creditedBotId ?? ''}`,
            label: `death`,
            detail: `${e.victimBotId} died${e.creditedBotId ? ` (credited ${e.creditedBotId})` : ''}`,
            tone: 'bad',
          })
          break
        case 'BULLET_SPAWN':
          lines.push({
            key: `BULLET_SPAWN:${e.bulletId}`,
            label: `bullet spawn`,
            detail: `${e.ownerBotId} @ ${e.pos.x},${e.pos.y} vel ${e.vel.x},${e.vel.y}`,
          })
          break
        case 'BULLET_HIT':
          lines.push({
            key: `BULLET_HIT:${e.bulletId}:${e.victimBotId}`,
            label: `bullet hit`,
            detail: `${e.bulletId} hit ${e.victimBotId} (${e.damage})`,
            tone: 'bad',
          })
          break
        case 'BULLET_DESPAWN':
          lines.push({
            key: `BULLET_DESPAWN:${e.bulletId}:${e.reason}`,
            label: `bullet despawn`,
            detail: `${e.bulletId} (${e.reason})`,
            tone: 'muted',
          })
          break
        case 'POWERUP_PICKUP':
          lines.push({
            key: `POWERUP_PICKUP:${e.powerupId}:${e.botId}`,
            label: `powerup pickup`,
            detail: `${e.botId} picked ${e.powerupType} (${e.loc.sector}/${e.loc.zone})`,
            tone: 'good',
          })
          break
        case 'POWERUP_SPAWN':
          lines.push({
            key: `POWERUP_SPAWN:${e.powerupId}`,
            label: `powerup spawn`,
            detail: `${e.powerupType} at ${e.loc.sector}/${e.loc.zone}`,
            tone: 'muted',
          })
          break
        case 'POWERUP_DESPAWN':
          lines.push({
            key: `POWERUP_DESPAWN:${e.powerupId}:${e.reason}`,
            label: `powerup despawn`,
            detail: `${e.powerupId} (${e.reason})`,
            tone: 'muted',
          })
          break
        case 'MATCH_END':
          lines.push({ key: 'MATCH_END', label: 'match end', detail: e.endReason, tone: 'muted' })
          break
        default:
          lines.push({ key: `${e.type}:${i}`, label: e.type, detail: JSON.stringify(e), tone: 'muted' })
          break
      }
    }

    return lines
  }, [selectedTickEvents])

  function createNewBot() {
    setMyBots((prev) => {
      const id = createNewLocalBotId(prev.bots.map((b) => b.id))
      const loadout = deriveLoadoutFromScriptOrDefault(starterSourceText)

      return {
        version: 2,
        selectedBotId: id,
        bots: [...prev.bots, { id, name: id, sourceText: applyLoadoutHeaderDirectives(starterSourceText, loadout), loadout }],
      }
    })
    setEditingBotId('BOT1')
  }

  function renameSelectedBot() {
    const current = selectedMyBot
    const next = window.prompt('Rename bot', current.name)
    if (next == null) return

    const trimmed = next.trim()
    if (!trimmed) return

    setMyBots((prev) => ({
      ...prev,
      bots: prev.bots.map((b) => (b.id === current.id ? { ...b, name: trimmed } : b)),
    }))
  }

  function deleteSelectedBot() {
    if (myBots.bots.length <= 1) return
    const ok = window.confirm(`Delete "${selectedMyBot.name}"?`)
    if (!ok) return

    setMyBots((prev) => {
      if (prev.bots.length <= 1) return prev

      const remaining = prev.bots.filter((b) => b.id !== prev.selectedBotId)
      const nextSelectedBotId = remaining[0]?.id ?? prev.selectedBotId

      return {
        version: 2,
        selectedBotId: nextSelectedBotId,
        bots: remaining.length ? remaining : prev.bots,
      }
    })

    setEditingBotId('BOT1')
  }

  function selectBotAsBot1(id: string) {
    setMyBots((prev) => ({ ...prev, selectedBotId: id }))
    setEditingBotId('BOT1')
  }

  function loadStarter() {
    const loadout = deriveLoadoutFromScriptOrDefault(starterSourceText)

    setMyBots((prev) => ({
      ...prev,
      bots: prev.bots.map((b) =>
        b.id === prev.selectedBotId
          ? { ...b, loadout, sourceText: applyLoadoutHeaderDirectives(starterSourceText, loadout) }
          : b,
      ),
    }))
    setEditingBotId('BOT1')
  }

  function setMyBotLoadoutSlot(slotIndex: 0 | 1 | 2, nextMod: ModuleId | null) {
    setMyBots((prev) => ({
      ...prev,
      bots: prev.bots.map((b) => {
        if (b.id !== prev.selectedBotId) return b

        const nextLoadout = [...(b.loadout ?? DEFAULT_WORKSHOP_LOADOUT)] as Loadout
        nextLoadout[slotIndex] = nextMod

        return {
          ...b,
          loadout: nextLoadout,
          sourceText: applyLoadoutHeaderDirectives(b.sourceText, nextLoadout),
        }
      }),
    }))
  }

  function setOpponent(slot: keyof OpponentAssignments, id: string) {
    setOpponents((prev) => normalizeOpponentAssignments({ ...prev, [slot]: id }, opponentPoolIds))
  }

  function randomizeOpponents() {
    const nonce = readOpponentNonce()
    const randomizeSeed = (seed >>> 0) ^ fnv1a32(selectedMyBot.sourceText ?? '') ^ nonce

    const ids = selectDistinctFromPool(randomizeSeed, opponentPoolIds, 3)

    setOpponents({ BOT2: ids[0], BOT3: ids[1], BOT4: ids[2] })
    writeOpponentNonce((nonce + 1) >>> 0)
  }

  async function handleRun() {
    setRunning(true)
    setRunError(null)

    try {
      const bots = SLOT_IDS.map((slotId) => {
        const sourceText = sourcesBySlot[slotId]
        const loadout = loadoutBySlot[slotId]
        return { slotId, sourceText, loadout }
      })
      const nextReplay: Replay = await runLocalInWorker({ seed, tickCap, bots })

      setAppliedRun({
        seed,
        tickCap,
        bot1Id: selectedMyBot.id,
        bot1Name: selectedMyBot.name,
        botSpecHashBySlot: currentBotSpecHashBySlot,
      })

      dispatch({ type: 'LOAD_REPLAY', replay: nextReplay })
    } catch (err) {
      setRunError(err instanceof Error ? err.message : String(err))
    } finally {
      setRunning(false)
    }
  }

  function optionsForOpponentSlot(slot: keyof OpponentAssignments) {
    const otherSlots = OPPONENT_SLOTS.filter((s) => s !== slot)
    const usedByOtherSlots = new Set(otherSlots.map((s) => opponents[s]))

    return opponentPool.filter((o) => o.id === opponents[slot] || !usedByOtherSlots.has(o.id))
  }

  const speedButtons = [0.5, 1, 2, 6] as const
  const effectiveTickCap = replay?.tickCap ?? tickCap

  const editorSourceText = sourcesBySlot[editingBotId]
  const editorReadOnly = editingBotId !== 'BOT1'

  const bot1LoadoutWarnings = React.useMemo(() => {
    const loadout = selectedMyBot.loadout ?? DEFAULT_WORKSHOP_LOADOUT

    const counts = new Map<ModuleId, number>()
    for (const mod of loadout) {
      if (mod == null) continue
      counts.set(mod, (counts.get(mod) ?? 0) + 1)
    }

    const dupes = [...counts.entries()]
      .filter(([, n]) => n > 1)
      .map(([m]) => m)

    const weaponCount = loadout.filter((m) => m === 'BULLET' || m === 'SAW').length

    const warnings: string[] = []
    if (dupes.length) warnings.push(`Duplicate modules: ${dupes.join(', ')}`)
    if (weaponCount > 1) warnings.push('More than one weapon selected (BULLET/SAW)')

    return warnings
  }, [selectedMyBot.loadout])

  return (
    <>
      <div className="workshop-header">
        <div>
          <h1 className="workshop-title">Workshop</h1>
          <div className="subtitle">Edit bots, run a deterministic local match, and inspect the replay.</div>
        </div>

        <div className="workshop-header-actions">
          <label className="mini-field">
            <div className="mini-label">Seed</div>
            <input className="mini-input" type="number" value={seed} onChange={(e) => setSeed(Number(e.target.value))} />
          </label>

          <label className="mini-field">
            <div className="mini-label">Tick cap</div>
            <input
              className="mini-input"
              type="number"
              value={tickCap}
              onChange={(e) => setTickCap(Math.max(1, Number(e.target.value)))}
            />
          </label>

          <div className="mini-field">
            <div className="mini-label">BOT1 (next run)</div>
            <div className="mini-input" style={{ display: 'flex', alignItems: 'center', width: 180, fontWeight: 700 }}>
              {selectedMyBot.name}
            </div>
          </div>

          <div className="mini-field">
            <div className="mini-label">Preview</div>
            <div
              className="mini-input"
              style={{ display: 'flex', alignItems: 'center', width: 180 }}
              title={appliedRun ? `Last run BOT1: ${appliedRun.bot1Name}` : undefined}
            >
              {previewStatusText}
            </div>
          </div>

          <button className="ui-button" onClick={handleRun} disabled={running}>
            {running ? 'Running…' : 'Run / Preview'}
          </button>
          <button className="ui-button ui-button-secondary" disabled>
            Save
          </button>
        </div>
      </div>

      {runError ? (
        <div className="panel" style={{ marginTop: 16, borderColor: 'rgba(239, 68, 68, 0.4)' }}>
          <strong style={{ color: '#fecaca' }}>Run failed</strong>
          <div className="muted" style={{ marginTop: 8 }}>{runError}</div>
        </div>
      ) : null}

      {playback.replay && !previewUpToDate ? (
        <div className="panel" style={{ marginTop: 16, borderColor: 'rgba(34, 197, 94, 0.22)' }}>
          <strong style={{ color: 'var(--text)' }}>Preview out of date</strong>
          <div className="muted" style={{ marginTop: 8 }}>
            BOT1 source or match settings changed since the last run. Click{' '}
            <strong style={{ color: 'var(--text)' }}>Run / Preview</strong> to apply and re-run.
          </div>
          {appliedRun ? (
            <div className="muted" style={{ marginTop: 8 }}>
              Last run BOT1: <strong style={{ color: 'var(--text)' }}>{appliedRun.bot1Name}</strong>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="workshop-grid" style={{ marginTop: 16 }}>
        <section className="panel">
          <div className="panel-title">My Bots</div>

          <div className="tab-row" style={{ marginTop: 10 }}>
            {myBots.bots.map((b) => (
              <button
                key={b.id}
                className={['tab', b.id === myBots.selectedBotId ? 'active' : ''].join(' ')}
                onClick={() => selectBotAsBot1(b.id)}
                title={b.id}
              >
                {b.name}
              </button>
            ))}
          </div>

          <div className="controls" style={{ marginTop: 10 }}>
            <button className="ui-button ui-button-secondary" type="button" onClick={createNewBot}>
              New bot
            </button>
            <button className="ui-button ui-button-secondary" type="button" onClick={renameSelectedBot}>
              Rename
            </button>
            <button
              className="ui-button ui-button-secondary"
              type="button"
              onClick={deleteSelectedBot}
              disabled={myBots.bots.length <= 1}
            >
              Delete
            </button>
          </div>

          <div className="panel-title" style={{ marginTop: 18 }}>
            Bot editor
          </div>

          <div className="tab-row" style={{ marginTop: 10 }}>
            {SLOT_IDS.map((id) => (
              <button
                key={id}
                className={['tab', id === editingBotId ? 'active' : ''].join(' ')}
                onClick={() => setEditingBotId(id)}
              >
                {id}
              </button>
            ))}
          </div>

          <div className="controls" style={{ marginTop: 10 }}>
            <button className="ui-button ui-button-secondary" type="button" onClick={loadStarter}>
              Load starter
            </button>

            <label className="mini-field">
              <div className="mini-label">BOT2</div>
              <select
                className="mini-input"
                value={opponents.BOT2}
                onChange={(e) => setOpponent('BOT2', e.target.value)}
              >
                {optionsForOpponentSlot('BOT2').map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.displayName}
                  </option>
                ))}
              </select>
            </label>

            <label className="mini-field">
              <div className="mini-label">BOT3</div>
              <select
                className="mini-input"
                value={opponents.BOT3}
                onChange={(e) => setOpponent('BOT3', e.target.value)}
              >
                {optionsForOpponentSlot('BOT3').map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.displayName}
                  </option>
                ))}
              </select>
            </label>

            <label className="mini-field">
              <div className="mini-label">BOT4</div>
              <select
                className="mini-input"
                value={opponents.BOT4}
                onChange={(e) => setOpponent('BOT4', e.target.value)}
              >
                {optionsForOpponentSlot('BOT4').map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.displayName}
                  </option>
                ))}
              </select>
            </label>

            <button className="ui-button ui-button-secondary" type="button" onClick={randomizeOpponents}>
              Randomize opponents
            </button>
          </div>

          {editorReadOnly ? (
            <div className="muted" style={{ marginTop: 10 }}>
              Opponent code is read-only. Select <strong style={{ color: 'var(--text)' }}>BOT1</strong> to edit your bot.
            </div>
          ) : null}

          {!editorReadOnly ? (
            <>
              <div className="controls" style={{ marginTop: 10 }}>
                <label className="mini-field">
                  <div className="mini-label">slot1</div>
                  <select
                    className="mini-input"
                    value={formatLoadoutOptionValue((selectedMyBot.loadout ?? DEFAULT_WORKSHOP_LOADOUT)[0] ?? null)}
                    onChange={(e) => setMyBotLoadoutSlot(0, parseLoadoutOptionValue(e.target.value))}
                  >
                    {LOADOUT_OPTION_VALUES.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="mini-field">
                  <div className="mini-label">slot2</div>
                  <select
                    className="mini-input"
                    value={formatLoadoutOptionValue((selectedMyBot.loadout ?? DEFAULT_WORKSHOP_LOADOUT)[1] ?? null)}
                    onChange={(e) => setMyBotLoadoutSlot(1, parseLoadoutOptionValue(e.target.value))}
                  >
                    {LOADOUT_OPTION_VALUES.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="mini-field">
                  <div className="mini-label">slot3</div>
                  <select
                    className="mini-input"
                    value={formatLoadoutOptionValue((selectedMyBot.loadout ?? DEFAULT_WORKSHOP_LOADOUT)[2] ?? null)}
                    onChange={(e) => setMyBotLoadoutSlot(2, parseLoadoutOptionValue(e.target.value))}
                  >
                    {LOADOUT_OPTION_VALUES.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              {bot1LoadoutWarnings.length ? (
                <div style={{ marginTop: 10, color: '#fecaca', fontSize: 12, lineHeight: 1.5 }}>
                  {bot1LoadoutWarnings.map((w) => (
                    <div key={w}>{w}</div>
                  ))}
                </div>
              ) : null}
            </>
          ) : null}

          <textarea
            className="code-editor"
            value={editorSourceText}
            readOnly={editorReadOnly}
            onChange={(e) => {
              if (editingBotId !== 'BOT1') return
              const nextSourceText = e.target.value
              setMyBots((prev) => {
                const current = prev.bots.find((b) => b.id === prev.selectedBotId)
                if (!current) return prev

                const nextText = applyLoadoutHeaderDirectives(nextSourceText, current.loadout ?? DEFAULT_WORKSHOP_LOADOUT)

                return {
                  ...prev,
                  bots: prev.bots.map((b) => (b.id === prev.selectedBotId ? { ...b, sourceText: nextText } : b)),
                }
              })
            }}
            spellCheck={false}
          />

          <div className="muted" style={{ marginTop: 10 }}>
            Loadout directives <code>;@slot1</code>, <code>;@slot2</code>, <code>;@slot3</code> are locked and kept in sync with the dropdowns.
          </div>
        </section>

        <section className="panel">
          <div className="panel-title">Arena</div>

          <div className="arena-wrap" style={{ marginTop: 10 }}>
            <ArenaCanvas renderState={renderState} selectedBotId={selectedBotId} />
          </div>

          <div className="controls" style={{ marginTop: 12 }}>
            <button
              className="ui-button ui-button-secondary"
              onClick={() => dispatch({ type: 'TOGGLE_PLAY' })}
              disabled={!replay}
            >
              {playback.playing ? 'Pause' : 'Play'}
            </button>

            <button
              className="ui-button ui-button-secondary"
              onClick={() => dispatch({ type: 'STEP', delta: 1 })}
              disabled={!replay || playback.playing}
            >
              Step
            </button>

            <button
              className="ui-button ui-button-secondary"
              onClick={() => dispatch({ type: 'RESTART' })}
              disabled={!replay}
            >
              Restart
            </button>

            <span className="muted" style={{ marginLeft: 8 }}>
              tick {playback.tick} / {effectiveTickCap}
            </span>
          </div>

          <div className="controls" style={{ marginTop: 10 }}>
            <div className="muted">Speed</div>
            {speedButtons.map((s) => (
              <button
                key={s}
                className={['chip', playback.speed === s ? 'active' : ''].join(' ')}
                onClick={() => dispatch({ type: 'SET_SPEED', speed: s })}
                disabled={!replay}
              >
                {s}×
              </button>
            ))}
          </div>

          <div style={{ marginTop: 10 }}>
            <input
              type="range"
              min={0}
              max={effectiveTickCap}
              value={clamp(playback.tick, 0, effectiveTickCap)}
              onChange={(e) => dispatch({ type: 'SET_TICK', tick: Number(e.target.value) })}
              disabled={!replay || playback.playing}
            />
          </div>
        </section>

        <section className="panel">
          <div className="panel-title">Inspector</div>

          <div className="tab-row" style={{ marginTop: 10 }}>
            {SLOT_IDS.map((id) => (
              <button
                key={id}
                className={['tab', id === selectedBotId ? 'active' : ''].join(' ')}
                onClick={() => setSelectedBotId(id)}
              >
                {id}
              </button>
            ))}
          </div>

          <div style={{ marginTop: 12 }} className="muted">
            {selectedBotSnapshot ? (
              <>
                <div>
                  <strong style={{ color: 'var(--text)' }}>{selectedBotId}</strong>
                </div>
                <div style={{ marginTop: 8 }}>HP: {selectedBotSnapshot.hp}</div>
                <div>Ammo: {selectedBotSnapshot.ammo}</div>
                <div>Energy: {selectedBotSnapshot.energy}</div>
                <div>Alive: {selectedBotSnapshot.alive ? 'yes' : 'no'}</div>
              </>
            ) : (
              'Run a replay to inspect bots.'
            )}
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="panel-title">Execution</div>
            <div
              style={{
                marginTop: 8,
                padding: 10,
                borderRadius: 10,
                background: 'rgba(0,0,0,0.35)',
              }}
            >
              {(() => {
                if (!replay) return <div className="muted">Run a match to inspect execution.</div>

                const exec = selectedTickEvents.find((e): e is Extract<KnownReplayEvent, { type: 'BOT_EXEC' }> => isKnownReplayEventType(e, 'BOT_EXEC'))
                if (!exec) return <div className="muted">(no BOT_EXEC)</div>

                return (
                  <div className="muted" style={{ lineHeight: 1.5 }}>
                    <div>
                      <strong style={{ color: 'var(--text)' }}>{exec.instrText}</strong>
                    </div>
                    <div style={{ marginTop: 6 }}>
                      pc {exec.pcBefore} → {exec.pcAfter}
                      {' • '}
                      result <strong style={{ color: 'var(--text)' }}>{exec.result}</strong>
                      {exec.reason ? (
                        <>
                          {' • '}
                          reason <strong style={{ color: '#fecaca' }}>{exec.reason}</strong>
                        </>
                      ) : null}
                    </div>
                  </div>
                )
              })()}
            </div>
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="panel-title" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span>Tick events</span>
              <button
                type="button"
                className={['chip', showRawTickEvents ? 'active' : ''].join(' ')}
                onClick={() => setShowRawTickEvents((v) => !v)}
                disabled={!replay}
                title="Toggle raw JSON"
              >
                Raw
              </button>
            </div>

            {replay ? (
              showRawTickEvents ? (
                <pre
                  style={{
                    marginTop: 8,
                    padding: 10,
                    borderRadius: 10,
                    background: 'rgba(0,0,0,0.35)',
                    overflow: 'auto',
                    height: 240,
                  }}
                >
                  {selectedTickEvents.length ? JSON.stringify(selectedTickEvents, null, 2) : '(no events)'}
                </pre>
              ) : (
                <div
                  style={{
                    marginTop: 8,
                    padding: 10,
                    borderRadius: 10,
                    background: 'rgba(0,0,0,0.35)',
                    overflow: 'auto',
                    height: 240,
                    fontFamily:
                      'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
                    fontSize: 12,
                    lineHeight: 1.55,
                  }}
                >
                  {selectedTickEventLines.length ? (
                    selectedTickEventLines.map((l) => {
                      const color =
                        l.tone === 'bad'
                          ? '#fecaca'
                          : l.tone === 'good'
                            ? 'rgba(134, 239, 172, 0.95)'
                            : 'rgba(148, 163, 184, 0.95)'

                      return (
                        <div key={l.key} style={{ marginBottom: 6 }}>
                          <div style={{ color }}>
                            <strong style={{ color: 'var(--text)' }}>{l.label}</strong>
                            {l.detail ? <span style={{ marginLeft: 8 }}>{l.detail}</span> : null}
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <div className="muted">(no events)</div>
                  )}
                </div>
              )
            ) : (
              <pre
                style={{
                  marginTop: 8,
                  padding: 10,
                  borderRadius: 10,
                  background: 'rgba(0,0,0,0.35)',
                  overflow: 'auto',
                  height: 240,
                }}
              >{'Run a match to see events.'}</pre>
            )}
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="panel-title">Loadout</div>
            {(() => {
              const configured = loadoutBySlot[selectedBotId] ?? DEFAULT_WORKSHOP_LOADOUT
              const headerBot = replay?.bots?.find((b) => b.slotId === selectedBotId)
              const resolved = headerBot?.loadout ?? configured
              const issues = headerBot?.loadoutIssues ?? []

              const row = (label: string, l: Loadout) => (
                <div style={{ marginTop: 6, lineHeight: 1.5 }}>
                  <div className="muted" style={{ fontSize: 12 }}>{label}</div>
                  <div>
                    slot1:{' '}
                    <strong style={{ color: 'var(--text)' }}>{formatLoadoutOptionValue(l?.[0] ?? null)}</strong>
                    {'  '}slot2:{' '}
                    <strong style={{ color: 'var(--text)' }}>{formatLoadoutOptionValue(l?.[1] ?? null)}</strong>
                    {'  '}slot3:{' '}
                    <strong style={{ color: 'var(--text)' }}>{formatLoadoutOptionValue(l?.[2] ?? null)}</strong>
                  </div>
                </div>
              )

              const showResolved =
                Boolean(replay) && (resolved[0] !== configured[0] || resolved[1] !== configured[1] || resolved[2] !== configured[2])

              return (
                <div className="muted" style={{ marginTop: 8 }}>
                  {row('Configured (input)', configured)}
                  {showResolved ? row('Resolved by engine', resolved) : null}

                  {issues.length ? (
                    <div style={{ marginTop: 10, color: '#fecaca', fontSize: 12, lineHeight: 1.5 }}>
                      <div style={{ fontWeight: 700, color: 'var(--text)' }}>Loadout issues</div>
                      {issues.map((i, idx) => (
                        <div key={idx}>
                          {i.kind} (slot {i.slot}{i.module ? `: ${i.module}` : ''})
                        </div>
                      ))}
                    </div>
                  ) : null}

                  {selectedBotId === 'BOT1' ? (
                    <div style={{ marginTop: 10 }}>
                      Edit BOT1 loadout in the bot editor. The <code>;@slot</code> header directives are locked and kept in sync with the dropdowns.
                    </div>
                  ) : null}
                </div>
              )
            })()}
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="panel-title">Instruction reference</div>
            <div style={{ marginTop: 10 }}>
              <Link className="ui-button ui-button-secondary" to="/docs">
                Open bot instructions
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  )
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v))
}

function clampInt(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, Math.floor(v)))
}

function powerupLocToWorld(loc: { sector: number; zone: number }): { x: number; y: number } {
  const sectorId = clampInt(loc.sector, 1, 9)
  const zone = clampInt(loc.zone, 0, 4)

  const sectorRow = Math.floor((sectorId - 1) / 3)
  const sectorCol = (sectorId - 1) % 3
  const sectorOriginX = sectorCol * 64
  const sectorOriginY = sectorRow * 64

  if (zone === 0) return { x: sectorOriginX + 32, y: sectorOriginY + 32 }

  const zoneOffsets: Record<number, { x: number; y: number }> = {
    1: { x: 0, y: 0 },
    2: { x: 32, y: 0 },
    3: { x: 0, y: 32 },
    4: { x: 32, y: 32 },
  }

  const off = zoneOffsets[zone] ?? { x: 0, y: 0 }
  return { x: sectorOriginX + off.x + 16, y: sectorOriginY + off.y + 16 }
}
